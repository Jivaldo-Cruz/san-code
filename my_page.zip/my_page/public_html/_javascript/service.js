/* 
    start: 03/01/2020
    autor: Jivaldo Da Cruz
    cargo: Programador
    page: SanCode
*/

//Sistema de venda

//Todos dados pessoais do comprador
var dadosPessoais = function() {
    var nome = document.getElementById("first_name").value;
    var apelido = document.getElementById("last_name").value;
    var email = document.getElementById("email").value;
    var mensagem = document.getElementById("textarea1").value;
    var preco = document.getElementById("quantia").value;
    var credite = document.getElementById("n_credito").value;
    
    //
    for(var x = 0; x < 1; x++){
        console.log("Nomes:",nome)
        console.log("Apelidos:",apelido)
        console.log("E-mail:",email)
        console.log("As mensagens:",mensagem)
    }
}


//Para botão pagar por prestação
var prestacao = function() {

    var data = new Date();//Pegar tudo sobre data
    var horas = data.getHours();
    var comprimento = new String();

    if(horas >= 6 && horas < 12){
        comprimento = "bom dia";
    }else if(horas >= 12 && horas < 19){
        comprimento = "boa tarde";
    }else{
        comprimento = "boa noite";
    }
    //=================================================
    var nome = document.getElementById("first_name");
    var preco = document.getElementById("quantia");
    var s_n = confirm("Olá "+ nome.value +", "+comprimento+"! Por prestação tens que pagar por 60% do valor.");
    const valorExato = preco.value;
    var result = valorExato / 1.5;
    if(s_n == true) {
        var insiraValor = prompt("Insira a quantia, 60% ("+Math.round(result)+") do valor $"+valorExato);
        if(parseInt(insiraValor) >= result) {
            console.log("Compras feita com sucesso!");
        }else {
            console.log("O dinheiro adicionado é inferior ao 60% do preço.");
        }
    }else {
        //Se for false o algoritmo não faz nada
    }
}