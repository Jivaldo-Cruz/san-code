/* 
    start: 20/11/2019
    autor: Jivaldo Da Cruz
    cargo: Programador
    page: SanCode
*/

//Slider Show
var arrImage = ["1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg", "6.jpg", "7.jpg", "8.jpg", "9.png", "10.png", "11.png", "12.jpg"];
var time, cont = 0;
var mudaFoto1 = function(){
    cont += 1;
    if(arrImage[cont] === undefined) {
        cont = 0;
        document.getElementById("slider-show").src = "_slider/"+arrImage[cont];
    }else {
        document.getElementById("slider-show").src = "_slider/"+arrImage[cont];
    }
    mudado();
}
var mudado = function() {
    time = setTimeout("mudaFoto1()", 5000);
}

window.addEventListener("load", mudado);


//Para carregar imagen de acordo com tamanho da tela
/*var elemento = document.getElementsByTagName("body").style.maxWidth = "993px";
console.log(elemento);
if(elemento == "993px"){
    console.log("A imagen do slider só é carregada na tela de um desktop");
}else{
    window.addEventListener("load", mudado);
}*/